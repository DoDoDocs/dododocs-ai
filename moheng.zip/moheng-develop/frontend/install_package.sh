#! /bin/bash

# 패키지 설치
npm install --legacy-peer-deps

# 서버 시작
pnpm run dev --host
