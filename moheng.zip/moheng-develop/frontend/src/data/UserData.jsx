import profileimg from "../assets/profileimg.png";

const UserData = {
    nickname: "mohenguser",
    birthday: "2000-01-01",
    genderType: "MEN",
    profileImageUrl: profileimg
};

export default UserData;
  