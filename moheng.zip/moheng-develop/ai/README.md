# 여행지 추천 시스템
## 버전
* 파이썬 버전: 3.11.x

## 실행 방법
```shell
pip install poetry
poetry shell
poetry install
python3 main.py
```
