package moheng.auth.exception;

public class InvalidInitAuthorityException extends RuntimeException {
    public InvalidInitAuthorityException(final String message) {
        super(message);
    }
}
