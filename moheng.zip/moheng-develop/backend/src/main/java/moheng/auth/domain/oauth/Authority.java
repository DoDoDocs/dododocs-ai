package moheng.auth.domain.oauth;

public enum Authority {
    GUEST,
    REGULAR_MEMBER,
    INIT_MEMBER,
    ADMIN
}
