package moheng.auth.exception;

public class InvalidOAuthServiceException extends RuntimeException {
    public InvalidOAuthServiceException(final String message) {
        super(message);
    }
}
