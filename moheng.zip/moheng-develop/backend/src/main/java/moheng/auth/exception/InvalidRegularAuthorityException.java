package moheng.auth.exception;

public class InvalidRegularAuthorityException extends RuntimeException {
    public InvalidRegularAuthorityException(final String message) {
        super(message);
    }
}
