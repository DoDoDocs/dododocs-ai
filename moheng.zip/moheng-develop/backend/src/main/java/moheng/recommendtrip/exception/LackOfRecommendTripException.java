package moheng.recommendtrip.exception;

public class LackOfRecommendTripException extends RuntimeException {
    public LackOfRecommendTripException(final String message) {
        super(message);
    }
}
