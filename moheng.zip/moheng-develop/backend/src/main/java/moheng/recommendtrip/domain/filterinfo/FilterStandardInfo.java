package moheng.recommendtrip.domain.filterinfo;

public interface FilterStandardInfo {
    long getInfo();
}

