package moheng.runner.data.dto;

public class TripRunner {
    private Long contentid;
    private String title;
    private String firstimage;
    private Double mapx;
    private Double mapy;
    private String overview;
    private String addr1;
    private String area_sigungu_combined;

    public Long getContentid() {
        return contentid;
    }

    public String getTitle() {
        return title;
    }

    public String getFirstimage() {
        return firstimage;
    }

    public Double getMapx() {
        return mapx;
    }

    public Double getMapy() {
        return mapy;
    }

    public String getOverview() {
        return overview;
    }

    public String getAddr1() {
        return addr1;
    }

    public String getArea_sigungu_combined() {
        return area_sigungu_combined;
    }
}
