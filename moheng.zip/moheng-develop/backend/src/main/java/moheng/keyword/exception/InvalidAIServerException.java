package moheng.keyword.exception;

public class InvalidAIServerException extends RuntimeException {
    public InvalidAIServerException(final String message) {
        super(message);
    }
}
