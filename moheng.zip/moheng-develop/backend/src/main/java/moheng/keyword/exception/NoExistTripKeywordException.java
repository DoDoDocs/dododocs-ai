package moheng.keyword.exception;

public class NoExistTripKeywordException extends RuntimeException {
    public NoExistTripKeywordException(final String message) {
        super(message);
    }
}
