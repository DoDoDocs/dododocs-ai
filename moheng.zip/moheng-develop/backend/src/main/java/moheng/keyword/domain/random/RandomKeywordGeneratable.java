package moheng.keyword.domain.random;

import moheng.keyword.domain.Keyword;

public interface RandomKeywordGeneratable {
    Keyword generate();
}
