package moheng.keyword.exception;

public class KeywordNameLengthException extends RuntimeException {
    public KeywordNameLengthException(final String message) {
        super(message);
    }
}
