package moheng;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MohengApplication {

	public static void main(String[] args) {
		SpringApplication.run(MohengApplication.class, args);
	}
}
