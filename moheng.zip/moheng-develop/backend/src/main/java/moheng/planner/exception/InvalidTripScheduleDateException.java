package moheng.planner.exception;

public class InvalidTripScheduleDateException extends RuntimeException {
    public InvalidTripScheduleDateException(final String message) {
        super(message);
    }
}
