package moheng.planner.exception;

public class InvalidTripScheduleNameException extends RuntimeException {
    public InvalidTripScheduleNameException(final String message) {
        super(message);
    }
}
