package moheng.planner.exception;

public class AlreadyExistTripScheduleException extends RuntimeException {
    public AlreadyExistTripScheduleException(final String message) {
        super(message);
    }
}
