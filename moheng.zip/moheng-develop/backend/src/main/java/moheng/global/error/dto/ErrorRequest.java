package moheng.global.error.dto;

public class ErrorRequest {
}
