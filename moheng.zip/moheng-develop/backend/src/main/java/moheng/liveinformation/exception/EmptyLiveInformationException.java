package moheng.liveinformation.exception;

public class EmptyLiveInformationException extends RuntimeException {
    public EmptyLiveInformationException(final String message) {
        super(message);
    }
}
