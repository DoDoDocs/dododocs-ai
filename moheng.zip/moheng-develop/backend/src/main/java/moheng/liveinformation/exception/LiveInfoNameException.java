package moheng.liveinformation.exception;

public class LiveInfoNameException extends RuntimeException {
    public LiveInfoNameException(final String message) {
        super(message);
    }
}

