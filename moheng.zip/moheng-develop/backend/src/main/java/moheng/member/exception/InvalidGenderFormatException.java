package moheng.member.exception;

public class InvalidGenderFormatException extends RuntimeException {
    public InvalidGenderFormatException(final String message) {
        super(message);
    }
}
