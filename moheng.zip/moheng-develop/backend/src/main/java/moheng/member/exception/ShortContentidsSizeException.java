package moheng.member.exception;

public class ShortContentidsSizeException extends RuntimeException {
    public ShortContentidsSizeException(final String message) {
        super(message);
    }
}
