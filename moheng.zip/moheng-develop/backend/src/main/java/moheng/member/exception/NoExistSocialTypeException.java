package moheng.member.exception;

public class NoExistSocialTypeException extends RuntimeException {
    public NoExistSocialTypeException(final String message) {
        super(message);
    }
}
