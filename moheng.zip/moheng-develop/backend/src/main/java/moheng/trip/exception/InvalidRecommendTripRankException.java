package moheng.trip.exception;

public class InvalidRecommendTripRankException extends RuntimeException {
    public InvalidRecommendTripRankException(final String message) {
        super(message);
    }
}
