package moheng.trip.exception;

public class NoExistRecommendTripException extends RuntimeException {
    public NoExistRecommendTripException(final String message) {
        super(message);
    }
}
