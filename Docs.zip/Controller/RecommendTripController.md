# 시스템 아키텍처

## 전체 구조
```mermaid
graph TD
    A[Client] --> B[Controller Layer]
    B --> C[Service Layer]
    C --> D[Repository Layer]
    D --> E[Database]
```

## 시스템 흐름
```mermaid
sequenceDiagram
    Client->>Controller: Request
    Controller->>Service: Process
    Service->>Repository: Data Access
    Repository->>Database: Query
```

## 주요 컴포넌트 설명
### Controller Layer
- **역할과 책임**: 클라이언트의 요청을 처리하고, 서비스 레이어와 상호작용하여 비즈니스 로직을 수행합니다.
- **주요 컨트롤러 목록**:
  - `RecommendTripController`: 추천 여행지 생성 및 조회 기능을 담당합니다.
- **공통 처리 로직**: 인증 및 요청 유효성 검사를 포함합니다.

### Service Layer
- **비즈니스 로직 구조**: 추천 여행지 생성 및 필터링 로직을 포함합니다.
- **주요 서비스 목록**:
  - `RecommendTripService`: 추천 여행지 관련 비즈니스 로직을 처리합니다.
- **트랜잭션 경계**: 데이터베이스 작업을 트랜잭션으로 묶어 일관성을 유지합니다.

### Repository Layer
- **역할과 책임**: 데이터베이스와의 상호작용을 담당합니다.
- **주요 리포지토리 목록**:
  - `RecommendTripRepository`: 추천 여행지 데이터 접근.
  - `TripRepository`: 여행지 데이터 접근.
  - `MemberRepository`: 회원 데이터 접근.
  - `TripKeywordRepository`: 여행지 키워드 데이터 접근.

### Database
- **역할과 책임**: 모든 데이터의 영속성을 보장합니다.

## API 엔드포인트

### 추천 여행지 생성
**POST** `/api/recommend`

#### 설명
추천 여행지를 생성합니다.

#### 요청
##### Parameters
| 이름 | 타입 | 필수 여부 | 설명 |
|------|------|-----------|------|
| accessor | Accessor | Required | 인증된 사용자 정보 |

##### Headers
| 이름 | 필수 여부 | 설명 |
|------|-----------|------|
| Authorization | Required | Bearer {token} |

##### Request Body
```json
{
    "tripId": 1
}
```

#### 응답
##### Success Response
- Status: 204 No Content

##### Error Response
- Status: 400 Bad Request
```json
{
    "error": "잘못된 요청입니다."
}
```
- Status: 404 Not Found
```json
{
    "error": "존재하지 않는 여행지입니다."
}
```

### 추천 여행지 조회
**GET** `/api/recommend`

#### 설명
사용자의 선호 위치에 기반하여 추천 여행지를 조회합니다.

#### 요청
##### Parameters
| 이름 | 타입 | 필수 여부 | 설명 |
|------|------|-----------|------|
| accessor | Accessor | Required | 인증된 사용자 정보 |

##### Headers
| 이름 | 필수 여부 | 설명 |
|------|-----------|------|
| Authorization | Required | Bearer {token} |

#### 응답
##### Success Response
- Status: 200 OK
```json
{
    "findTripResponses": [
        {
            "trip": {
                "id": 1,
                "name": "여행지 이름",
                "placeName": "장소 이름",
                "description": "여행지 설명",
                "tripImageUrl": "이미지 URL",
                "visitedCount": 10
            },
            "keywords": ["키워드1", "키워드2"]
        }
    ]
}
```

##### Error Response
- Status: 404 Not Found
```json
{
    "error": "추천 여행지를 찾을 수 없습니다."
}
```

## 주요 데이터 흐름
1. 클라이언트가 추천 여행지 생성 요청을 보냅니다.
2. `RecommendTripController`가 요청을 받아 `RecommendTripService`에 전달합니다.
3. `RecommendTripService`는 회원과 여행지 정보를 검증하고 추천 여행지를 생성합니다.
4. 클라이언트가 추천 여행지 조회 요청을 보냅니다.
5. `RecommendTripController`가 요청을 받아 `TripFilterStrategyProvider`를 통해 필터 전략을 찾고, `TripsWithKeywordProvider`를 통해 추천 여행지를 조회합니다.
6. 최종적으로 클라이언트에게 추천 여행지 목록을 반환합니다.