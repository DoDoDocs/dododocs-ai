# 시스템 아키텍처

## 전체 구조
```mermaid
graph TD
    A[Client] --> B[Controller Layer]
    B --> C[Service Layer]
    C --> D[Repository Layer]
    D --> E[Database]
```

## 시스템 흐름
```mermaid
sequenceDiagram
    Client->>Controller: Request
    Controller->>Service: Process
    Service->>Repository: Data Access
    Repository->>Database: Query
```

## 주요 컴포넌트 설명
### Controller Layer
- 역할과 책임: 클라이언트의 요청을 처리하고, 서비스 레이어와의 상호작용을 통해 비즈니스 로직을 수행합니다.
- 주요 컨트롤러 목록:
  - `MemberController`: 회원 관련 API를 처리합니다.
- 공통 처리 로직: 인증 및 초기 인증을 위한 어노테이션을 사용하여 요청 파라미터를 처리합니다.

### Service Layer
- 비즈니스 로직 구조: 회원 관련 비즈니스 로직을 처리하며, 데이터베이스와의 상호작용을 위해 리포지토리 레이어를 사용합니다.
- 주요 서비스 목록:
  - `MemberService`: 회원의 CRUD 및 관련 비즈니스 로직을 처리합니다.
- 트랜잭션 경계: `@Transactional` 어노테이션을 사용하여 트랜잭션을 관리합니다.

## API 문서

# 회원 관련 API

## 개요
- 컨트롤러 설명: 회원 관련 요청을 처리하는 API입니다.
- 기본 URL 경로: `/api/member`
- 공통 요청/응답 형식: JSON 형식으로 요청 및 응답합니다.

## API 엔드포인트

### 사용자 정보 조회
**GET** `/api/member/me`

#### 설명
현재 로그인한 사용자의 정보를 조회합니다.

#### 요청
##### Parameters
| 이름 | 타입 | 필수 여부 | 설명 |
|------|------|-----------|------|
| accessor | Accessor | Required | 인증된 사용자 정보 |

##### Headers
| 이름 | 필수 여부 | 설명 |
|------|-----------|------|
| Authorization | Required | Bearer {token} |

#### 응답
##### Success Response
- Status: 200 OK
```json
{
    "id": 1,
    "profileImageUrl": "http://example.com/image.jpg",
    "nickname": "user123",
    "birthday": "1990-01-01",
    "genderType": "MALE"
}
```

##### Error Response
- Status: 404 Not Found
```json
{
    "error": "존재하지 않는 회원입니다."
}
```

### 프로필 가입
**POST** `/api/member/signup/profile`

#### 설명
사용자의 프로필 정보를 등록합니다.

#### 요청
##### Parameters
| 이름 | 타입 | 필수 여부 | 설명 |
|------|------|-----------|------|
| accessor | Accessor | Required | 인증된 사용자 정보 |

##### Request Body
```json
{
    "nickname": "user123",
    "birthday": "1990-01-01",
    "genderType": "MALE"
}
```

#### 응답
##### Success Response
- Status: 204 No Content

##### Error Response
- Status: 400 Bad Request
```json
{
    "error": "중복되는 닉네임이 존재합니다."
}
```

### 생활 정보 가입
**POST** `/api/member/signup/liveinfo`

#### 설명
사용자의 생활 정보를 등록합니다.

#### 요청
##### Parameters
| 이름 | 타입 | 필수 여부 | 설명 |
|------|------|-----------|------|
| accessor | Accessor | Required | 인증된 사용자 정보 |

##### Request Body
```json
{
    "liveInfoNames": ["info1", "info2"]
}
```

#### 응답
##### Success Response
- Status: 204 No Content

##### Error Response
- Status: 404 Not Found
```json
{
    "error": "존재하지 않는 생활정보입니다."
}
```

### 관심 여행지 가입
**POST** `/api/member/signup/trip`

#### 설명
사용자의 관심 여행지를 등록합니다.

#### 요청
##### Parameters
| 이름 | 타입 | 필수 여부 | 설명 |
|------|------|-----------|------|
| accessor | Accessor | Required | 인증된 사용자 정보 |

##### Request Body
```json
{
    "contentIds": [1, 2, 3]
}
```

#### 응답
##### Success Response
- Status: 204 No Content

##### Error Response
- Status: 400 Bad Request
```json
{
    "error": "AI 맞춤 추천을 위해 관심 여행지를 5개 이상, 10개 이하로 선택해야합니다."
}
```

### 닉네임 중복 체크
**POST** `/api/member/check/nickname`

#### 설명
닉네임의 중복 여부를 체크합니다.

#### 요청
##### Parameters
| 이름 | 타입 | 필수 여부 | 설명 |
|------|------|-----------|------|
| accessor | Accessor | Required | 인증된 사용자 정보 |

##### Request Body
```json
{
    "nickname": "user123"
}
```

#### 응답
##### Success Response
- Status: 200 OK
```json
{
    "message": "사용 가능한 닉네임입니다."
}
```

##### Error Response
- Status: 400 Bad Request
```json
{
    "error": "중복되는 닉네임이 존재합니다."
}
```

### 프로필 업데이트
**PUT** `/api/member/profile`

#### 설명
사용자의 프로필 정보를 업데이트합니다.

#### 요청
##### Parameters
| 이름 | 타입 | 필수 여부 | 설명 |
|------|------|-----------|------|
| accessor | Accessor | Required | 인증된 사용자 정보 |

##### Request Body
```json
{
    "nickname": "newNickname",
    "birthday": "1990-01-01",
    "genderType": "FEMALE",
    "profileImageUrl": "http://example.com/new_image.jpg"
}
```

#### 응답
##### Success Response
- Status: 204 No Content

##### Error Response
- Status: 404 Not Found
```json
{
    "error": "존재하지 않는 회원입니다."
}
```

### 권한 및 프로필 이미지 조회
**GET** `/api/member/authority/profile`

#### 설명
사용자의 권한 및 프로필 이미지를 조회합니다.

#### 요청
##### Parameters
| 이름 | 타입 | 필수 여부 | 설명 |
|------|------|-----------|------|
| accessor | Accessor | Required | 인증된 사용자 정보 |

#### 응답
##### Success Response
- Status: 200 OK
```json
{
    "authority": "REGULAR_MEMBER",
    "profileImageUrl": "http://example.com/image.jpg"
}
```

##### Error Response
- Status: 404 Not Found
```json
{
    "error": "존재하지 않는 회원입니다."
}
```