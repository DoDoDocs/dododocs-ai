# 시스템 아키텍처 문서

## 전체 구조
```mermaid
graph TD
    A[Client] --> B[Controller Layer]
    B --> C[Service Layer]
    C --> D[Repository Layer]
    D --> E[Database]
```

## 시스템 흐름
```mermaid
sequenceDiagram
    Client->>Controller: Request
    Controller->>Service: Process
    Service->>Repository: Data Access
    Repository->>Database: Query
```

## 주요 컴포넌트 설명
### Controller Layer
- **역할과 책임**: 클라이언트의 요청을 처리하고, 서비스 레이어와의 상호작용을 통해 비즈니스 로직을 수행합니다.
- **주요 컨트롤러 목록**:
  - `PlannerController`: 여행 일정 관련 API를 처리합니다.
- **공통 처리 로직**: 인증 정보를 포함한 요청을 처리합니다.

### Service Layer
- **비즈니스 로직 구조**: 비즈니스 로직을 구현하며, 데이터베이스와의 상호작용을 위한 리포지토리 호출을 포함합니다.
- **주요 서비스 목록**:
  - `PlannerService`: 여행 일정 관련 비즈니스 로직을 처리합니다.
- **트랜잭션 경계**: 데이터 변경이 필요한 메서드는 `@Transactional` 어노테이션을 사용하여 트랜잭션을 관리합니다.

## API 문서

### PlannerController

#### 개요
- **컨트롤러 설명**: 여행 일정 관련 API를 제공하는 컨트롤러입니다.
- **기본 URL 경로**: `/api/planner`
- **공통 요청/응답 형식**: JSON 형식의 요청 및 응답을 사용합니다.

## API 엔드포인트

### 최근 여행 일정 조회
**GET** `/api/planner/recent`

#### 설명
회원의 최근 여행 일정을 조회합니다.

#### 요청
##### Parameters
| 이름 | 타입 | 필수 여부 | 설명 |
|------|------|-----------|------|
| accessor | Accessor | Required | 인증 정보 |

##### Headers
| 이름 | 필수 여부 | 설명 |
|------|-----------|------|
| Authorization | Required | Bearer {token} |

#### 응답
##### Success Response
- Status: 200 OK
```json
{
    "tripScheduleResponses": [
        {
            "scheduleId": 1,
            "scheduleName": "여행 일정 1",
            "startDate": "2023-10-01",
            "endDate": "2023-10-05"
        }
    ]
}
```

##### Error Response
- Status: 404 Not Found
```json
{
    "error": "존재하지 않는 유저입니다."
}
```

### 이름으로 여행 일정 조회
**GET** `/api/planner/name`

#### 설명
회원의 여행 일정을 이름으로 조회합니다.

#### 요청
##### Parameters
| 이름 | 타입 | 필수 여부 | 설명 |
|------|------|-----------|------|
| accessor | Accessor | Required | 인증 정보 |

##### Headers
| 이름 | 필수 여부 | 설명 |
|------|-----------|------|
| Authorization | Required | Bearer {token} |

#### 응답
##### Success Response
- Status: 200 OK
```json
{
    "tripScheduleResponses": [
        {
            "scheduleId": 2,
            "scheduleName": "여행 일정 2",
            "startDate": "2023-11-01",
            "endDate": "2023-11-05"
        }
    ]
}
```

##### Error Response
- Status: 404 Not Found
```json
{
    "error": "존재하지 않는 유저입니다."
}
```

### 날짜로 여행 일정 조회
**GET** `/api/planner/date`

#### 설명
회원의 여행 일정을 시작 날짜로 조회합니다.

#### 요청
##### Parameters
| 이름 | 타입 | 필수 여부 | 설명 |
|------|------|-----------|------|
| accessor | Accessor | Required | 인증 정보 |

##### Headers
| 이름 | 필수 여부 | 설명 |
|------|-----------|------|
| Authorization | Required | Bearer {token} |

#### 응답
##### Success Response
- Status: 200 OK
```json
{
    "tripScheduleResponses": [
        {
            "scheduleId": 3,
            "scheduleName": "여행 일정 3",
            "startDate": "2023-12-01",
            "endDate": "2023-12-05"
        }
    ]
}
```

##### Error Response
- Status: 404 Not Found
```json
{
    "error": "존재하지 않는 유저입니다."
}
```

### 여행 일정 업데이트
**PUT** `/api/planner/schedule`

#### 설명
회원의 여행 일정을 업데이트합니다.

#### 요청
##### Parameters
| 이름 | 타입 | 필수 여부 | 설명 |
|------|------|-----------|------|
| accessor | Accessor | Required | 인증 정보 |

##### Headers
| 이름 | 필수 여부 | 설명 |
|------|-----------|------|
| Authorization | Required | Bearer {token} |

##### Request Body
```json
{
    "scheduleId": 1,
    "scheduleName": "업데이트된 여행 일정",
    "startDate": "2023-10-10",
    "endDate": "2023-10-15"
}
```

#### 응답
##### Success Response
- Status: 204 No Content

##### Error Response
- Status: 400 Bad Request
```json
{
    "error": "동일한 이름의 여행 일정이 이미 존재합니다."
}
```

### 여행 일정 삭제
**DELETE** `/api/planner/schedule/{scheduleId}`

#### 설명
회원의 여행 일정을 삭제합니다.

#### 요청
##### Parameters
| 이름 | 타입 | 필수 여부 | 설명 |
|------|------|-----------|------|
| accessor | Accessor | Required | 인증 정보 |
| scheduleId | Long | Required | 삭제할 일정 ID |

##### Headers
| 이름 | 필수 여부 | 설명 |
|------|-----------|------|
| Authorization | Required | Bearer {token} |

#### 응답
##### Success Response
- Status: 204 No Content

##### Error Response
- Status: 404 Not Found
```json
{
    "error": "존재하지 않는 여행 일정입니다."
}
```

## 결론
이 문서는 `PlannerController`와 관련된 API의 구조와 흐름을 설명합니다. 각 API 엔드포인트는 요청 및 응답 형식을 명확히 정의하고 있으며, 인증 및 오류 처리에 대한 정보를 포함하고 있습니다.