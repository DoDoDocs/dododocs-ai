# 시스템 아키텍처

## 전체 구조
```mermaid
graph TD
    A[Client] --> B[Controller Layer]
    B --> C[Service Layer]
    C --> D[Repository Layer]
    D --> E[Database]
```

## 시스템 흐름
```mermaid
sequenceDiagram
    Client->>Controller: Request
    Controller->>Service: Process
    Service->>Repository: Data Access
    Repository->>Database: Query
```

## 주요 컴포넌트 설명
### Controller Layer
- 역할과 책임: 클라이언트의 요청을 처리하고, 서비스 레이어와의 상호작용을 통해 비즈니스 로직을 수행합니다.
- 주요 컨트롤러 목록: `TripScheduleController`
- 공통 처리 로직: 인증을 위한 `@Authentication` 어노테이션 사용

### Service Layer
- 비즈니스 로직 구조: `TripScheduleService`가 여행 일정 생성, 수정, 삭제 등의 비즈니스 로직을 처리합니다.
- 주요 서비스 목록: 
  - `createTripSchedule`
  - `addCurrentTripOnPlannerSchedule`
  - `findTripsOnSchedule`
  - `updateTripOrdersOnSchedule`
  - `deleteTripOnSchedule`
- 트랜잭션 경계: `@Transactional` 어노테이션을 사용하여 데이터 일관성을 유지합니다.

## API 문서

# Trip Schedule API

## 개요
- 컨트롤러 설명: 여행 일정 관련 API를 제공하는 컨트롤러입니다.
- 기본 URL 경로: `/api/schedule`
- 공통 요청/응답 형식: JSON 형식

## API 엔드포인트

### Create Trip Schedule
**POST** `/api/schedule`

#### 설명
새로운 여행 일정을 생성합니다.

#### 요청
##### Parameters
| 이름 | 타입 | 필수 여부 | 설명 |
|------|------|-----------|------|
| accessor | Accessor | Required | 인증된 사용자 정보 |

##### Headers
| 이름 | 필수 여부 | 설명 |
|------|-----------|------|
| Authorization | Required | Bearer {token} |

##### Request Body
```json
{
    "scheduleName": "여행 일정 이름",
    "startDate": "2023-10-01",
    "endDate": "2023-10-10"
}
```

#### 응답
##### Success Response
- Status: 204 No Content

##### Error Response
- Status: 400 Bad Request
```json
{
    "error": "존재하지 않는 유저입니다."
}
```

### Add Trip On Schedule
**POST** `/api/schedule/trip/{tripId}`

#### 설명
지정된 여행을 일정에 추가합니다.

#### 요청
##### Parameters
| 이름 | 타입 | 필수 여부 | 설명 |
|------|------|-----------|------|
| tripId | Long | Required | 추가할 여행 ID |

##### Request Body
```json
{
    "scheduleIds": [1, 2, 3]
}
```

#### 응답
##### Success Response
- Status: 204 No Content

##### Error Response
- Status: 404 Not Found
```json
{
    "error": "존재하지 않는 여행입니다."
}
```

### Find Trips On Schedule
**GET** `/api/schedule/trips/{scheduleId}`

#### 설명
지정된 일정에 포함된 여행 목록을 조회합니다.

#### 요청
##### Parameters
| 이름 | 타입 | 필수 여부 | 설명 |
|------|------|-----------|------|
| scheduleId | Long | Required | 조회할 일정 ID |

#### 응답
##### Success Response
- Status: 200 OK
```json
{
    "tripScheduleResponse": {
        "scheduleName": "여행 일정 이름",
        "startDate": "2023-10-01",
        "endDate": "2023-10-10"
    },
    "findTripsOnSchedules": [
        {
            "tripId": 1,
            "tripName": "여행 이름"
        }
    ]
}
```

### Update Trip Orders On Schedule
**POST** `/api/schedule/trips/orders/{scheduleId}`

#### 설명
일정 내 여행의 순서를 업데이트합니다.

#### 요청
##### Parameters
| 이름 | 타입 | 필수 여부 | 설명 |
|------|------|-----------|------|
| scheduleId | Long | Required | 업데이트할 일정 ID |

##### Request Body
```json
{
    "tripIds": [1, 2, 3]
}
```

#### 응답
##### Success Response
- Status: 204 No Content

##### Error Response
- Status: 404 Not Found
```json
{
    "error": "존재하지 않는 일정입니다."
}
```

### Delete Trip On Schedule
**DELETE** `/api/schedule/{scheduleId}/{tripId}`

#### 설명
일정에서 특정 여행을 삭제합니다.

#### 요청
##### Parameters
| 이름 | 타입 | 필수 여부 | 설명 |
|------|------|-----------|------|
| scheduleId | Long | Required | 삭제할 일정 ID |
| tripId | Long | Required | 삭제할 여행 ID |

#### 응답
##### Success Response
- Status: 204 No Content

##### Error Response
- Status: 404 Not Found
```json
{
    "error": "존재하지 않는 일정 여행지입니다."
}
```

## 응답 상태 코드
- 200 OK: 요청이 성공적으로 처리됨
- 204 No Content: 요청이 성공적으로 처리되었으나 반환할 데이터가 없음
- 400 Bad Request: 잘못된 요청
- 404 Not Found: 요청한 리소스가 존재하지 않음

## 인증 및 권한
- 모든 API 요청은 `Authorization` 헤더를 통해 인증된 사용자만 접근할 수 있습니다. `@Authentication` 어노테이션을 사용하여 인증 정보를 처리합니다.