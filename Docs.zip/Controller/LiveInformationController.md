# 시스템 아키텍처 문서

## 전체 구조
```mermaid
graph TD
    A[Client] --> B[Controller Layer]
    B --> C[Service Layer]
    C --> D[Repository Layer]
    D --> E[Database]
```

## 시스템 흐름
```mermaid
sequenceDiagram
    Client->>Controller: Request
    Controller->>Service: Process
    Service->>Repository: Data Access
    Repository->>Database: Query
```

## 주요 컴포넌트 설명
### Controller Layer
- 역할과 책임: 클라이언트의 요청을 처리하고, 서비스 레이어와의 상호작용을 통해 비즈니스 로직을 수행합니다.
- 주요 컨트롤러 목록:
  - `LiveInformationController`: 생활정보 관련 API를 처리합니다.
- 공통 처리 로직: 요청 및 응답의 형식을 정의하고, 예외 처리를 수행합니다.

### Service Layer
- 비즈니스 로직 구조: 서비스 레이어는 비즈니스 로직을 구현하며, 데이터베이스와의 상호작용을 담당하는 레포지토리와 연결됩니다.
- 주요 서비스 목록:
  - `LiveInformationService`: 생활정보 관련 비즈니스 로직을 처리합니다.
  - `MemberLiveInformationService`: 회원의 생활정보 관련 비즈니스 로직을 처리합니다.
- 트랜잭션 경계: `@Transactional` 어노테이션을 사용하여 트랜잭션을 관리합니다.

## API 문서

### Live Information API

#### 개요
- 컨트롤러 설명: 생활정보 관련 API를 제공하는 컨트롤러입니다.
- 기본 URL 경로: `/api/live/info`
- 공통 요청/응답 형식: JSON 형식의 요청 및 응답을 사용합니다.

### API 엔드포인트

#### 1. 모든 생활정보 조회
**GET** `/api/live/info/all`

##### 설명
모든 생활정보를 조회합니다.

##### 요청
- Parameters: 없음
- Headers: 없음

##### 응답
###### Success Response
- Status: 200 OK
```json
{
    "liveInformationResponses": [
        {
            "id": 1,
            "name": "생활정보1"
        },
        {
            "id": 2,
            "name": "생활정보2"
        }
    ]
}
```

###### Error Response
- Status: 500 Internal Server Error
```json
{
    "error": "서버 오류 메시지"
}
```

#### 2. 생활정보 생성
**POST** `/api/live/info`

##### 설명
새로운 생활정보를 생성합니다.

##### 요청
###### Request Body
```json
{
    "name": "새로운 생활정보"
}
```

##### 응답
###### Success Response
- Status: 204 No Content

###### Error Response
- Status: 400 Bad Request
```json
{
    "error": "잘못된 요청 메시지"
}
```

#### 3. 여행과 생활정보 연결
**POST** `/api/live/info/trip/{tripId}/{liveInfoId}`

##### 설명
특정 여행과 생활정보를 연결합니다.

##### 요청
- Parameters:
  - `tripId`: 여행 ID (필수)
  - `liveInfoId`: 생활정보 ID (필수)

##### 응답
###### Success Response
- Status: 204 No Content

###### Error Response
- Status: 404 Not Found
```json
{
    "error": "존재하지 않는 여행지 또는 생활정보입니다."
}
```

## 응답 상태 코드
- 200 OK: 요청이 성공적으로 처리되었습니다.
- 204 No Content: 요청이 성공적으로 처리되었지만 반환할 데이터가 없습니다.
- 400 Bad Request: 잘못된 요청입니다.
- 404 Not Found: 요청한 리소스가 존재하지 않습니다.
- 500 Internal Server Error: 서버에서 오류가 발생했습니다.

## 인증 및 권한
- 모든 API 요청은 인증이 필요합니다. 요청 헤더에 `Authorization: Bearer {token}` 형식으로 토큰을 포함해야 합니다.

## 주요 데이터 흐름
- 클라이언트가 API 요청을 보내면, 컨트롤러가 요청을 처리하고 서비스 레이어에 전달합니다.
- 서비스 레이어는 비즈니스 로직을 수행하고, 필요한 경우 레포지토리를 통해 데이터베이스와 상호작용합니다.
- 최종적으로, 서비스 레이어의 결과를 컨트롤러가 받아 클라이언트에게 응답합니다.