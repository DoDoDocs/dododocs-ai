# 시스템 아키텍처 문서

## 전체 구조
```mermaid
graph TD
    A[Client] --> B[AuthController]
    B --> C[AuthService]
    C --> D[TokenManager]
    C --> E[MemberService]
    D --> F[Database]
    E --> F
```

## 시스템 흐름
```mermaid
sequenceDiagram
    Client->>AuthController: Request for OAuth URI
    AuthController->>AuthService: Generate URI
    AuthService->>OAuthProvider: Get OAuth URI
    AuthController->>Client: Return OAuth URI

    Client->>AuthController: Login with code
    AuthController->>AuthService: Generate token with code
    AuthService->>OAuthClient: Get OAuth member
    AuthService->>MemberService: Check and create member
    AuthService->>TokenManager: Create member token
    AuthController->>Client: Return access token and set refresh token cookie

    Client->>AuthController: Extend login with refresh token
    AuthController->>AuthService: Generate renewal access token
    AuthService->>TokenManager: Generate renewal access token
    AuthController->>Client: Return renewal access token

    Client->>AuthController: Logout
    AuthController->>AuthService: Remove refresh token
    AuthService->>TokenManager: Remove refresh token
    AuthController->>Client: No content response
```

## 주요 컴포넌트 설명

### AuthController
- 역할과 책임: 클라이언트의 요청을 처리하고, AuthService와 상호작용하여 인증 관련 작업을 수행합니다.
- 주요 메서드:
  - `generateUri`: OAuth URI 생성
  - `login`: 로그인 처리 및 토큰 생성
  - `extendLogin`: 리프레시 토큰을 사용하여 액세스 토큰 갱신
  - `logout`: 로그아웃 처리

### AuthService
- 역할과 책임: 비즈니스 로직을 처리하고, OAuth 인증 및 토큰 관리를 수행합니다.
- 주요 메서드:
  - `generateTokenWithCode`: OAuth 코드로부터 토큰 생성
  - `generateRenewalAccessToken`: 리프레시 토큰으로부터 액세스 토큰 갱신
  - `removeRefreshToken`: 로그아웃 시 리프레시 토큰 제거
  - `extractMemberId`: 액세스 토큰으로부터 멤버 ID 추출

### TokenManager
- 역할과 책임: 토큰 생성 및 검증을 담당합니다.
- 주요 메서드:
  - `createMemberToken`: 멤버 토큰 생성
  - `generateRenewalAccessToken`: 리프레시 토큰으로부터 새로운 액세스 토큰 생성
  - `removeRefreshToken`: 리프레시 토큰 제거
  - `getMemberId`: 액세스 토큰으로부터 멤버 ID 추출

### MemberService
- 역할과 책임: 멤버 관련 데이터 접근 및 관리를 담당합니다.
- 주요 메서드:
  - `existsByEmail`: 이메일로 멤버 존재 여부 확인
  - `save`: 새로운 멤버 저장
  - `findByEmail`: 이메일로 멤버 조회

## API 엔드포인트

### Generate OAuth URI
**GET** `/api/auth/{oAuthProvider}/link`

#### 설명
OAuth 제공자로부터 인증 URI를 생성합니다.

#### 요청
##### Parameters
| 이름         | 타입   | 필수 여부 | 설명               |
|--------------|--------|-----------|--------------------|
| oAuthProvider | string | Required  | OAuth 제공자 이름 |

#### 응답
##### Success Response
- Status: 200 OK
```json
{
    "uri": "https://example.com/oauth/authorize"
}
```

### Login
**POST** `/api/auth/{oAuthProvider}/login`

#### 설명
OAuth 제공자로부터 받은 코드를 사용하여 로그인하고, 액세스 토큰 및 리프레시 토큰을 생성합니다.

#### 요청
##### Parameters
| 이름         | 타입   | 필수 여부 | 설명               |
|--------------|--------|-----------|--------------------|
| oAuthProvider | string | Required  | OAuth 제공자 이름 |

##### Request Body
```json
{
    "code": "authorization_code"
}
```

#### 응답
##### Success Response
- Status: 201 Created
```json
{
    "accessToken": "generated_access_token"
}
```

### Extend Login
**POST** `/api/auth/extend/login`

#### 설명
리프레시 토큰을 사용하여 액세스 토큰을 갱신합니다.

#### 요청
##### Headers
| 이름         | 필수 여부 | 설명               |
|--------------|-----------|--------------------|
| Cookie       | Required  | 리프레시 토큰 포함 |

#### 응답
##### Success Response
- Status: 201 Created
```json
{
    "accessToken": "renewed_access_token"
}
```

### Logout
**DELETE** `/api/auth/logout`

#### 설명
로그아웃을 수행하고 리프레시 토큰을 제거합니다.

#### 요청
##### Headers
| 이름         | 필수 여부 | 설명               |
|--------------|-----------|--------------------|
| Cookie       | Required  | 리프레시 토큰 포함 |

#### 응답
##### Success Response
- Status: 204 No Content
```json
{}
```

## 가능한 모든 응답 상태 코드
- 200 OK: 요청이 성공적으로 처리됨
- 201 Created: 리소스가 성공적으로 생성됨
- 204 No Content: 요청이 성공적으로 처리되었으나 반환할 내용이 없음
- 400 Bad Request: 잘못된 요청
- 401 Unauthorized: 인증 실패
- 404 Not Found: 요청한 리소스를 찾을 수 없음
- 500 Internal Server Error: 서버 오류

## 인증 및 권한
- 모든 API 엔드포인트는 적절한 인증을 요구합니다. 리프레시 토큰은 쿠키를 통해 전달되어야 합니다.