# 시스템 아키텍처

## 전체 구조
```mermaid
graph TD
    A[Client] --> B[KeywordController]
    B --> C[KeywordService]
    C --> D[KeywordRepository]
    C --> D2[TripKeywordRepository]
    C --> D3[TripRepository]
    D --> E[Database]
    D2 --> E
    D3 --> E
```

## 시스템 흐름
```mermaid
sequenceDiagram
    Client->>KeywordController: Request
    KeywordController->>KeywordService: Process
    KeywordService->>KeywordRepository: Data Access
    KeywordService->>TripKeywordRepository: Data Access
    KeywordService->>TripRepository: Data Access
```

## 주요 컴포넌트 설명
### KeywordController
- 역할과 책임: 클라이언트의 요청을 처리하고, 서비스 레이어와의 상호작용을 통해 비즈니스 로직을 수행합니다.
- 주요 컨트롤러 목록:
  - `recommendTripsByKeywords`: 키워드에 기반한 추천 여행 조회
  - `findAllKeywords`: 모든 키워드 조회
  - `createKeyword`: 새로운 키워드 생성
  - `createTripKeyword`: 여행과 키워드의 관계 생성
  - `findTripsByRandomKeyword`: 랜덤 키워드에 기반한 여행 조회

### KeywordService
- 비즈니스 로직 구조: 키워드 관련 비즈니스 로직을 처리하며, 데이터베이스와의 상호작용을 관리합니다.
- 주요 서비스 목록:
  - `findAllKeywords`: 모든 키워드 조회
  - `createKeyword`: 키워드 생성
  - `findRecommendTripsByKeywords`: 키워드에 기반한 추천 여행 조회
  - `findRecommendTripsByRandomKeyword`: 랜덤 키워드에 기반한 추천 여행 조회
- 트랜잭션 경계: `@Transactional` 어노테이션을 사용하여 데이터베이스 트랜잭션을 관리합니다.

### Repository Layer
- 역할과 책임: 데이터베이스와의 상호작용을 담당하며, CRUD 작업을 수행합니다.
- 주요 레포지토리 목록:
  - `KeywordRepository`: 키워드 관련 데이터 접근
  - `TripKeywordRepository`: 여행과 키워드의 관계 데이터 접근
  - `TripRepository`: 여행 관련 데이터 접근

## API 엔드포인트

### 추천 여행 조회
**POST** `/api/keyword/trip/recommend`

#### 설명
키워드에 기반하여 추천 여행을 조회합니다.

#### 요청
##### Parameters
| 이름 | 타입 | 필수 여부 | 설명 |
|------|------|-----------|------|
| accessor | Accessor | Required | 인증 정보 |

##### Headers
| 이름 | 필수 여부 | 설명 |
|------|-----------|------|
| Authorization | Required | Bearer {token} |

##### Request Body
```json
{
    "keywordIds": [1, 2, 3]
}
```

#### 응답
##### Success Response
- Status: 200 OK
```json
{
    "findTripResponses": [
        {
            "trip": {
                "id": 1,
                "name": "Trip to Paris"
            },
            "keywords": ["romantic", "city"]
        }
    ]
}
```

##### Error Response
- Status: 400 Bad Request
```json
{
    "error": "일부 키워드가 존재하지 않습니다."
}
```

### 모든 키워드 조회
**GET** `/api/keyword`

#### 설명
모든 키워드를 조회합니다.

#### 요청
##### Parameters
| 이름 | 타입 | 필수 여부 | 설명 |
|------|------|-----------|------|
| accessor | Accessor | Required | 인증 정보 |

##### Headers
| 이름 | 필수 여부 | 설명 |
|------|-----------|------|
| Authorization | Required | Bearer {token} |

#### 응답
##### Success Response
- Status: 200 OK
```json
{
    "findAllKeywordResponses": [
        {
            "keyword": "travel"
        },
        {
            "keyword": "adventure"
        }
    ]
}
```

### 키워드 생성
**POST** `/api/keyword`

#### 설명
새로운 키워드를 생성합니다.

#### 요청
##### Request Body
```json
{
    "keyword": "beach"
}
```

#### 응답
##### Success Response
- Status: 204 No Content

### 여행과 키워드 관계 생성
**POST** `/api/keyword/trip`

#### 설명
여행과 키워드의 관계를 생성합니다.

#### 요청
##### Request Body
```json
{
    "tripId": 1,
    "keywordId": 2
}
```

#### 응답
##### Success Response
- Status: 204 No Content

### 랜덤 키워드에 기반한 여행 조회
**GET** `/api/keyword/random/trip`

#### 설명
랜덤 키워드에 기반하여 추천 여행을 조회합니다.

#### 요청
##### Headers
| 이름 | 필수 여부 | 설명 |
|------|-----------|------|
| Authorization | Required | Bearer {token} |

#### 응답
##### Success Response
- Status: 200 OK
```json
{
    "keywordName": "beach",
    "findTripResponses": [
        {
            "trip": {
                "id": 1,
                "name": "Trip to Hawaii"
            },
            "keywords": ["beach", "sunny"]
        }
    ]
}
```