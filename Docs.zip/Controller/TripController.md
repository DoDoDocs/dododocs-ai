# 시스템 아키텍처 문서

## 전체 구조
```mermaid
graph TD
    A[Client] --> B[TripController]
    B --> C[TripService]
    C --> D[TripRepository]
    C --> D1[RecommendTripRepository]
    C --> D2[MemberRepository]
    C --> D3[MemberTripRepository]
    C --> D4[TripKeywordRepository]
    D --> E[Database]
```

## 시스템 흐름
```mermaid
sequenceDiagram
    Client->>TripController: Request
    TripController->>TripService: Process
    TripService->>TripRepository: Data Access
    TripService->>RecommendTripRepository: Data Access
    TripService->>MemberRepository: Data Access
    TripService->>MemberTripRepository: Data Access
    TripService->>TripKeywordRepository: Data Access
```

## 주요 컴포넌트 설명

### TripController
- 역할과 책임: 클라이언트의 요청을 처리하고, TripService와 상호작용하여 적절한 응답을 반환합니다.
- 주요 컨트롤러 목록:
  - `createTrip`: 새로운 여행을 생성합니다.
  - `findTopTripsOrderByVisitedCount`: 방문 수에 따라 상위 여행을 조회합니다.
  - `findTripWithSimilarTrips`: 특정 여행과 유사한 여행을 조회합니다.
  - `createMemberTrip`: 사용자가 여행을 즐겨찾기에 추가합니다.

### TripService
- 비즈니스 로직 구조: 여행 관련 비즈니스 로직을 처리하며, 데이터베이스와의 상호작용을 관리합니다.
- 주요 서비스 목록:
  - `createTrip`: 여행을 생성합니다.
  - `findWithSimilarOtherTrips`: 특정 여행과 유사한 여행을 찾습니다.
  - `findTop30OrderByVisitedCountDesc`: 방문 수에 따라 상위 30개의 여행을 조회합니다.
- 트랜잭션 경계: `@Transactional` 어노테이션을 사용하여 데이터베이스 작업의 원자성을 보장합니다.

## API 엔드포인트

### Create Trip
**POST** `/api/trip`

#### 설명
새로운 여행을 생성합니다.

#### 요청
##### Request Body
```json
{
    "name": "여행 이름",
    "placeName": "장소 이름",
    "contentId": 123,
    "description": "여행 설명",
    "tripImageUrl": "http://example.com/image.jpg"
}
```

#### 응답
##### Success Response
- Status: 204 No Content

### Find Top Trips
**GET** `/api/trip/find/interested`

#### 설명
방문 수에 따라 상위 여행을 조회합니다.

#### 응답
##### Success Response
- Status: 200 OK
```json
{
    "findTripResponses": [
        {
            "trip": {
                "id": 1,
                "name": "여행 이름",
                "placeName": "장소 이름",
                "contentId": 123,
                "description": "여행 설명",
                "tripImageUrl": "http://example.com/image.jpg"
            },
            "keywords": ["키워드1", "키워드2"]
        }
    ]
}
```

### Find Trip With Similar Trips
**GET** `/api/trip/find/{tripId}`

#### 설명
특정 여행과 유사한 여행을 조회합니다.

#### 요청
##### Parameters
| 이름 | 타입 | 필수 여부 | 설명 |
|------|------|-----------|------|
| tripId | long | Required | 조회할 여행의 ID |

##### Headers
| 이름 | 필수 여부 | 설명 |
|------|-----------|------|
| Authorization | Required | Bearer {token} |

#### 응답
##### Success Response
- Status: 200 OK
```json
{
    "findTripResponse": {
        "trip": {
            "id": 1,
            "name": "여행 이름",
            "placeName": "장소 이름",
            "contentId": 123,
            "description": "여행 설명",
            "tripImageUrl": "http://example.com/image.jpg"
        },
        "keywords": ["키워드1", "키워드2"]
    },
    "similarTripResponses": {
        "trips": [
            {
                "id": 2,
                "name": "유사 여행 이름",
                "placeName": "유사 장소 이름"
            }
        ]
    }
}
```

### Create Member Trip
**POST** `/api/trip/member/{tripId}`

#### 설명
사용자가 여행을 즐겨찾기에 추가합니다.

#### 요청
##### Parameters
| 이름 | 타입 | 필수 여부 | 설명 |
|------|------|-----------|------|
| tripId | long | Required | 추가할 여행의 ID |

##### Headers
| 이름 | 필수 여부 | 설명 |
|------|-----------|------|
| Authorization | Required | Bearer {token} |

#### 응답
##### Success Response
- Status: 204 No Content

## 응답 상태 코드
- 200 OK: 요청이 성공적으로 처리되었습니다.
- 204 No Content: 요청이 성공적으로 처리되었지만 반환할 데이터가 없습니다.
- 400 Bad Request: 잘못된 요청입니다.
- 404 Not Found: 요청한 리소스를 찾을 수 없습니다.
- 500 Internal Server Error: 서버 내부 오류가 발생했습니다.

## 인증 및 권한
- 모든 API 엔드포인트는 인증이 필요하며, `Authorization` 헤더에 Bearer 토큰을 포함해야 합니다.