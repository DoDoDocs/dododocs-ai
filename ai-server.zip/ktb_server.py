import logging
import time
from fastapi import FastAPI
import uvicorn
from ktb_src import *  # 전체 경로를 명시
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
import shutil
# 로깅 설정
logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.ERROR)

app = FastAPI()

class DocRequest(BaseModel):
    git_path: str
    s3_path: str

class ChatRequest(BaseModel):
    git_path: str
    query: str
    chat_history: Optional[List[Dict[str, Any]]] = None


@app.post("/generate_doc")
async def generate_doc(request: DocRequest):
    """Git 저장소에서 서비스 코드를 분석하여 문서 생성"""
    clone_dir, output_directory, repo_name = parse_repo_url(request.git_path)
    try:
        start_time = time.perf_counter()
        print("start")
        repo_path = repo_name+".zip"
        download_zip_from_s3(bucket_name, request.s3_path, repo_path)
        extract_zip(repo_path, clone_dir)
        java_files = file_list(clone_dir)
        
        directory_path = check_service_annotation(java_files)

        # asyncio.run() 제거하고 await 사용
        await generate_docs_async(directory_path, output_directory)
        end_time = time.perf_counter()
        print(f"총 소요 시간: {end_time - start_time} 초")

        await summarize_docs_async(output_directory)
        end_time = time.perf_counter()
        print(f"총 소요 시간: {end_time - start_time} 초")

        readme_content = await generate_readme(request.git_path, clone_dir, max_tokens=MAX_TOKEN_LENGTH)
        usage_content = await generate_usage(request.git_path, clone_dir, max_tokens=MAX_TOKEN_LENGTH)

        final_content = update_readme_with_usage(readme_content, usage_content)

        readme_file_path = clone_dir+"/"+"README.md"
        
        if final_content:
            with open(readme_file_path, "w", encoding="utf-8") as f:
                f.write(final_content)
            print("README.md가 성공적으로 생성되었습니다.")
        else:
            print("README.md 생성에 실패했습니다.")
        end_time = time.perf_counter()
        print(f"총 소요 시간: {end_time - start_time} 초")

        description = read_description_from_readme(readme_file_path)
        image_url, image_path = generate_image(description, clone_dir)
        update_readme_with_image(file_path=readme_file_path, image_path=image_path)
        print("README.md 파일에 이미지가 추가되었습니다.")

        end_time = time.perf_counter()
        print(f"총 소요 시간: {end_time - start_time} 초")


        doc_count = add_data_to_db(repo_name, output_directory)
        print(f"Added {doc_count} chunks to the database")
        
        zip_path = output_directory.rstrip('/')+".zip"
        upload_key = output_directory.rstrip('/').lstrip('./')+".zip"

        #create_zip(output_directory, zip_path)
        create_zip(clone_dir, repo_name+".zip")
        upload_zip_to_s3(bucket_name, repo_name+".zip", repo_name+".zip")

        url = get_presigned_url(bucket_name, "README_test.md.zip")

        if os.path.exists(repo_path):
            os.remove(repo_path)
            print(f"repo_path 파일이 삭제되었습니다: {repo_path}")

        if os.path.exists(clone_dir):
            shutil.rmtree(clone_dir)  # 디렉토리와 그 내용을 모두 삭제
            print(f"clone_dir 디렉토리가 삭제되었습니다: {clone_dir}")

        user_path = os.path.join('.', clone_dir.split('/')[1]) 
        if os.path.exists(user_path):
            shutil.rmtree(user_path)  # 디렉토리와 그 내용을 모두 삭제
            print(f"user_path 디렉토리가 삭제되었습니다: {user_path}")

        return { 
            "message": f"Documentation generated successfully for {repo_name}",
            "chunks_count": doc_count,
            "url": url,
            "upload_key": upload_key
        }

    except Exception as e:
        logger.error(f"Error in document generation: {str(e)}")
        return {"error": f"Document generation failed: {str(e)}"}
    

@app.post("/chat")
async def chat(request: ChatRequest):
    """사용자 쿼리에 대한 응답 생성"""
    try:
        #print("/chat chat_history : ", request.chat_history)
        # Call the function to get the response (must be iterable or async generator)
        response = codebase_chat(request.query, request.git_path, request.chat_history)
        return StreamingResponse(response, media_type="text/plain")

    except Exception as e:
        logger.error(f"Error in chat: {str(e)}")
        return {"error": f"Chat failed: {str(e)}"}

if __name__ == "__main__":
    try:
        # 초기 설정
        port = int(os.getenv("PORT", 8000))
        logger.info("Initializing test repository...")

        # FastAPI 서버 실행
        logger.info("Starting FastAPI server...")
        uvicorn.run(
            "ktb_server:app",
            host="0.0.0.0",
            port=port,
            reload=False,  # 개발 환경에서 코드 변경 시 자동 재시작
            reload_dirs=["ktb_final_project"],
            workers=4     # 워커 프로세스 수
        )

    except Exception as e:
        logger.error(f"Server initialization failed: {str(e)}")
        raise